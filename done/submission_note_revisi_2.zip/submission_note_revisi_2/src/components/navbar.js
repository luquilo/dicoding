function Navbar(props) {
    return (
      <div className="note-app__header">
        <h1>Notes</h1>
        
      </div>
    );
  }
  
  export default Navbar;

  