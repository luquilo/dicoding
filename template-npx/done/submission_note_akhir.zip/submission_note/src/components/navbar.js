function Navbar(props) {
    return (
      <div className="note-app__header">
        <h1>Notes</h1>
        <div className="note-search">
          <input 
          onChange={props.onChangeSearchKeyword}
          type="text"
          placeholder="Cari catatan ..."
          value={props.valueSearchKeyword} />
        </div>
      </div>
    );
  }
  
  export default Navbar;