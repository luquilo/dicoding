function EmptyDataMessage() {
    return (
      <div>
        <p className="notes-list__empty-message">Tidak ada catatan</p>
      </div>
    );
  }
  
  export default EmptyDataMessage;