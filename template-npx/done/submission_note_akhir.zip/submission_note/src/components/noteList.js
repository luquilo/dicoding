function NoteList({ children, title }) {
    return (
      <>
        <h2>{title}</h2>
        <div className="notes-list">
          {children}
        </div>
      </>
    );
  }

  export default NoteList;