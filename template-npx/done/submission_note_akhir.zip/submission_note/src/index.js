import React from "react";
import { createRoot } from "react-dom/client";
import "./style/style.css";
import FormNotes from "./components/noteinput";
import ContainerContent from "./components/containerContent";
import NoteList from "./components/noteList";
import EmptyDataMessage from "./components/emptyNote";
import { getInitialData } from "./utils";
import NoteItem from "./components/noteItem";
import Navbar from "./components/navbar";




class NotesPribadi extends React.Component {
  constructor(props) {
    super(props);

    //inisialisasi state
    this.state = {
      data: [],
      archives: [],
      searchKeyword: "",
      newNotes: {
        title: "",
        note: "",
      },
    };

    this.onSubmitNotes = this.onSubmitNotes.bind(this);
  }

  // menggunakan setState()
  componentDidMount() {
    const data = getInitialData();
    this.setState((previousState) => {
      return {
        ...previousState,
        data,
      };
    });
  }

  // handler pencarian
  onChangeSearchKeyword = (value) => {
    this.setState((previousState) => {
      return {
        ...previousState,
        value,
      };
    });
  };

  // memfilter data berdasarkan pencarian
  filteredData = (data) => {
    const { searchKeyword } = this.state;
    if (searchKeyword.length > 0) {
      return data.filter((value) => value.title.includes(searchKeyword));
    }
    return data;
  };

  // handle perubahan title note baru
  onChangeTitleNotes = (value) => {
    this.setState((previousState) => {
      return {
        ...previousState,
        newNotes: {
          ...previousState.newNotes,
          title: value,
        },
      };
    });
  };

  // handle perubahan isi note baru
  onChangeNotes = (value) => {
    this.setState((previousState) => {
      return {
        ...previousState,
        newNotes: {
          ...previousState.newNotes,
          note: value,
        },
      };
    });
  };

  // submit data catatan baru
  onSubmitNotes = () => {
    const { newNotes } = this.state;
    const dataNote = {
      id: +new Date(),
      title: newNotes.title,
      body: newNotes.note,
      createdAt: new Date().toISOString(),
      archived: false,
    };
    const newDataNotes = this.state.data.concat(dataNote);
    this.setState({
      data: newDataNotes,
      newNotes: {
        title: "",
        note: "",
      },
    });
  };

  // mencari data note berdasarkan id
  findIndexNote = (id) => {
    const { data } = this.state;
    for (const index in data) {
      if (data[index].id === id) {
        return index;
      }
    }
    return -1;
  };

  // menghapus note
  onDeleteNotes = (id) => {
    if (true) {
      const index = this.findIndexNote(id);
      const deletedData = this.state.data;
      deletedData.splice(index, 1);

      this.setState((previousState) => {
        return {
          ...previousState,
          data: deletedData,
        };
      });
    }
  };

  // merubah status archived atau tidak
  onChangeStatusNote = (id, status) => {
    const changedData = this.state.data.map((data) => {
      if (data.id === id) {
        return {
          ...data,
          archived: !status,
        };
      } else {
        return data;
      }
    });
    this.setState({ data: changedData });
  };

  render() {
    let archivedNote = [];
    let activeNote = [];
    const filteredData = this.filteredData(this.state.data);

    filteredData.forEach((note) => {
      if (note.archived) {
        archivedNote.push(note);
      } else {
        activeNote.push(note);
      }
    });

    return (
      <>
        <Navbar
          onChangeSearchKeyword={(val) =>
            this.onChangeSearchKeyword(val.target.value)
          }
          valueSearchKeyword={this.state.searchKeyword}
        />
        <ContainerContent>
          <FormNotes
            onSubmitNotes={(event) => {
              event.preventDefault();
              this.onSubmitNotes();
            }}
            onChangeNotes={(value) => this.onChangeNotes(value.target.value)}
            onChangeTitleNotes={(value) =>
              this.onChangeTitleNotes(value.target.value)
            }
            valueForm={this.state.newNotes}
          />
          <NoteList title="Catatan Aktif">
            {activeNote.length > 0 ? (
              activeNote.map((data) => (
                <NoteItem
                  onChangeStatusNote={(id, status) =>
                    this.onChangeStatusNote(id, status)
                  }
                  onDeleteNotes={(id, isArchived) =>
                    this.onDeleteNotes(id, isArchived)
                  }
                  data={data}
                  key={data.id}
                />
              ))
            ) : (
              <EmptyDataMessage />
            )}
          </NoteList>
          <NoteList title="Arsip">
            {archivedNote.length > 0 ? (
              archivedNote.map((data) => (
                <NoteItem
                  onChangeStatusNote={(id, status) =>
                    this.onChangeStatusNote(id, status)
                  }
                  onDeleteNotes={(id, isArchived) =>
                    this.onDeleteNotes(id, isArchived)
                  }
                  data={data}
                  key={data.id}
                />
              ))
            ) : (
              <EmptyDataMessage />
            )}
          </NoteList>
        </ContainerContent>
      </>
    );
  }
}

const root = createRoot(document.getElementById("root"));
root.render(<NotesPribadi />);
