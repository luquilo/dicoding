function ContainerContent({ children }) {
  return (
    <div className="note-app__body">
      {children}
    </div>
  );
}

export default ContainerContent;