function FormNotes(props) {
  const { valueForm, onSubmitNotes, onChangeNotes, onChangeTitleNotes } = props;
  return (
    <div className="note-input">
      <h2>Buat catatan</h2>
      <form onSubmit={onSubmitNotes}>
        <p className="note-input__title__char-limit">
          Sisa karakter: {50 - valueForm.note.length}
        </p>
        <input
          className="note-input__title"
          type="text"
          placeholder="Ini adalah judul ..."
          required
          value={valueForm.title}
          onChange={onChangeTitleNotes}
        />
        <textarea
          className="note-input__body"
          type="text"
          placeholder="Tuliskan catatanmu di sini ..." 
          required
          maxLength={50}
          value={valueForm.note}
          onChange={onChangeNotes}
        >
        </textarea>
        <button type="submit">
          Buat
        </button>
      </form>
    </div>
  );
}

export default FormNotes;