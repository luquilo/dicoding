import React from 'react';
import { createRoot } from 'react-dom/client';
// import style
import './styles/style.css';
// components
import Header from './components//header';
import FormNotes from './components/formNotes';
import ContainerContent from './components/containerContent';
import CardList from './components/cardList';
import CardNotes from './components/cardNotes';
import EmptyDataMessage from './components/emptyDataMessage';
// import data
import { getInitialData } from './utils';

class Notes extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      data: [],
      archives: [],
      searchKeyword: '',
      newNotes: {
        title: '',
        note: '',
      },
    };

    this.onSubmitNotes = this.onSubmitNotes.bind(this);
  };

  // mengambil data
  componentDidMount() {
    const data = getInitialData();
    this.setState((previousState) => {
      return {
        ...previousState,
        data,
      }
    });
  }

  // handle perubahan keyword search
  onChangeSearchKeyword = (searchKeyword) => {
    this.setState((previousState) => {
      return {
        ...previousState,
        searchKeyword
      }
    })
  }

  // memfilter data berdasarkan pencarian
  filteredData = (data) => {
    const { searchKeyword } = this.state;
    if (searchKeyword.length > 0) {
      return data.filter(value => value.title.includes(searchKeyword));
    };
    return data;
  }

  // handle perubahan title note baru
  onChangeTitleNotes = (val) => {
    this.setState((previousState) => {
      return {
        ...previousState,
        newNotes: {
          ...previousState.newNotes,
          title: val
        }
      }
    })
  }

  // handle perubahan isi note baru
  onChangeNotes = (val) => {
    this.setState((previousState) => {
      return {
        ...previousState,
        newNotes: {
          ...previousState.newNotes,
          note: val
        }
      }
    })
  }

  // submit data catatan baru
  onSubmitNotes = () => {
    const { newNotes } = this.state;
    const dataNote = {
      id: +new Date(),
      title: newNotes.title,
      body: newNotes.note,
      createdAt: new Date().toISOString(),
      archived: false,
    }
    const newDataNotes = this.state.data.concat(dataNote);
    this.setState({
      data: newDataNotes,
      newNotes: {
        title: '',
        note: '',
      },
    });
  }

  // mencari data note berdasarkan id
  findIndexNote = (id) => {
    const { data } = this.state;
    for (const index in data) {
      if (data[index].id === id) {
        return index;
      }
    }
    return -1;
  }

  // menghapus note
  onDeleteNotes = (id, isArchived) => {
    const deleteConfirm = window.confirm('Kamu yakin akan menghapus data catatan?');
    if (deleteConfirm) {
      const index = this.findIndexNote(id);
      const deletedData = this.state.data
      deletedData.splice(index, 1);

      this.setState((previousState) => {
        return {
          ...previousState,
          data: deletedData
        }
      })
    }
  }

  // merubah status archives
  onChangeStatusNote = (id, status) => {
    const changedData = this.state.data.map(data => {
      if (data.id === id) {
        return {
          ...data,
          archived: !status,
        }
      } else {
        return data
      }
    });
    this.setState({ data: changedData });
  }

  render() {
    let archivedNote = [];
    let activeNote = [];
    const filteredData = this.filteredData(this.state.data);

    filteredData.forEach((note) => {
      if (note.archived) {
        archivedNote.push(note);
      } else {
        activeNote.push(note);
      }
    });

    return (
      <>
        <Header
          onChangeSearchKeyword={(val) => this.onChangeSearchKeyword(val.target.value)}
          valueSearchKeyword={this.state.searchKeyword}
        />
        <ContainerContent>
          <FormNotes
            onSubmitNotes={(event) => {
              event.preventDefault()
              this.onSubmitNotes()
            }}
            onChangeNotes={(val) => this.onChangeNotes(val.target.value)}
            onChangeTitleNotes={(val) => this.onChangeTitleNotes(val.target.value)}
            valueForm={this.state.newNotes}
          />
          <CardList title="Catatan Aktif">
            {
              activeNote.length > 0 ? activeNote.map(data => <CardNotes
                onChangeStatusNote={(id, status) => this.onChangeStatusNote(id, status)}
                onDeleteNotes={(id, isArchived) => this.onDeleteNotes(id, isArchived)}
                data={data}
                key={data.id}
              />) : (<EmptyDataMessage />)
            }
          </CardList>
          <CardList title="Arsip">
            {
              archivedNote.length > 0 ? archivedNote.map(data => <CardNotes
                onChangeStatusNote={(id, status) => this.onChangeStatusNote(id, status)}
                onDeleteNotes={(id, isArchived) => this.onDeleteNotes(id, isArchived)}
                data={data}
                key={data.id}
              />) : (<EmptyDataMessage />)
            }
          </CardList>
        </ContainerContent>
      </>
    );
  }
}


const root = createRoot(document.getElementById('root'));
root.render(<Notes />);

// referensi
// https://dicoding-react-note-app.netlify.app
